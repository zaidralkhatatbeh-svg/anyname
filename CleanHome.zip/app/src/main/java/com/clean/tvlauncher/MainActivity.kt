package com.clean.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var row: LinearLayout
    private lateinit var label: TextView
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF0A0A12.toInt(), 0xFF1C1C2E.toInt())
            )
            setPadding(dp(48), dp(28), dp(48), dp(28))
        }

        val clock = TextClock(this).apply {
            format12Hour = "h:mm a"
            format24Hour = "HH:mm"
            setTextColor(Color.WHITE)
            textSize = 22f
            gravity = Gravity.END
        }
        root.addView(clock, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))

        row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            setPadding(dp(40), dp(30), dp(40), dp(30))
        }
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
            addView(row)
        }
        root.addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        label = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 28f
            gravity = Gravity.CENTER
            minHeight = dp(56)
        }
        root.addView(label, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        populate()
    }

    @Deprecated("Home screen ignores Back")
    override fun onBackPressed() {}

    private fun populate() {
        row.removeAllViews()
        val pm = packageManager
        val hidden = prefs.getStringSet("hidden", emptySet())!!.toSet()
        val apps = listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
            .flatMap { c -> pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(c), 0) }
            .distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != packageName && it.activityInfo.packageName !in hidden }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        for (ri in apps) row.addView(appTile(ri))
        row.addView(settingsTile())
        row.getChildAt(0)?.requestFocus()
    }

    private fun appTile(ri: ResolveInfo): View {
        val pm = packageManager
        val name = ri.loadLabel(pm).toString()
        val pkg = ri.activityInfo.packageName
        val cls = ri.activityInfo.name
        val banner = ri.activityInfo.loadBanner(pm)
        val img = ImageView(this)
        if (banner != null) {
            img.setImageDrawable(banner)
            img.scaleType = ImageView.ScaleType.CENTER_CROP
        } else {
            img.setImageDrawable(ri.loadIcon(pm))
            img.scaleType = ImageView.ScaleType.FIT_CENTER
            img.setPadding(dp(36), dp(20), dp(36), dp(20))
        }
        return card(img, name,
            onClick = {
                try {
                    startActivity(
                        Intent(Intent.ACTION_MAIN)
                            .setClassName(pkg, cls)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                    )
                } catch (e: Exception) {
                    Toast.makeText(this, "Can't open $name", Toast.LENGTH_SHORT).show()
                }
            },
            onLong = {
                AlertDialog.Builder(this)
                    .setTitle("Hide $name from home?")
                    .setPositiveButton("Hide") { _, _ ->
                        val s = prefs.getStringSet("hidden", emptySet())!!.toMutableSet()
                        s.add(pkg)
                        prefs.edit().putStringSet("hidden", s).apply()
                        populate()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            })
    }

    private fun settingsTile(): View {
        val tv = TextView(this).apply {
            text = "Settings"
            setTextColor(Color.WHITE)
            textSize = 24f
            gravity = Gravity.CENTER
        }
        return card(tv, "Settings (hold to show hidden apps)",
            onClick = {
                try {
                    startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    Toast.makeText(this, "Can't open Settings", Toast.LENGTH_SHORT).show()
                }
            },
            onLong = {
                AlertDialog.Builder(this)
                    .setTitle("Show all hidden apps again?")
                    .setPositiveButton("Show") { _, _ ->
                        prefs.edit().remove("hidden").apply()
                        populate()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            })
    }

    private fun card(content: View, name: String, onClick: () -> Unit, onLong: () -> Unit): View {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(0xFF26263A.toInt())
        }
        val ring = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(Color.TRANSPARENT)
        }
        return FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(256), dp(144)).apply {
                setMargins(dp(14), 0, dp(14), 0)
            }
            background = bg
            foreground = ring
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            isFocusable = true
            isClickable = true
            addView(content, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            setOnClickListener { onClick() }
            setOnLongClickListener { onLong(); true }
            setOnFocusChangeListener { v, focused ->
                val s = if (focused) 1.15f else 1f
                v.animate().scaleX(s).scaleY(s).setDuration(160).start()
                v.elevation = if (focused) dp(16).toFloat() else 0f
                ring.setStroke(if (focused) dp(3) else 0, Color.WHITE)
                if (focused) label.text = name
            }
        }
    }
}
